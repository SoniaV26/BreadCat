/*setTimeout(() => {
    console.log("hello");
}, 5000);*/

/*const getTimer = (time, value) => 
    new Promise(resolve => {
        setTimeout(() => resolve(value), time);
});

//Hello TImer is a promise
const helloTimer = getTimer(500, "promise value asdf");

//use '.then' to be notified when a promise resolves
helloTimer.then(()=> {
    console.log("hello world");
    console.log(helloTimer);
});
console.log(helloTimer);*/

const express = require("express");
exphbs = require("express-handlebars");
const app = express();

app.engine("handlebars", exphbs());
app.set("view engine", "handlebars");
app.use(express.urlencoded());

app.get("/", (req, res) => {
    res.render("index");
});

app.post("/message",(req, res) => {
    console.log(req.body);
    res.redirect("/");
});


app.listen(3000, () => console.log("listening on http://localhost:3000"));
